# Venom Multispecialty Hospital — Website

A responsive, multi-page **Health Care Website** built for the **MANTRA 2026 Summer School** Frontend Assignment (HTML5, CSS3, JavaScript, GitHub, Netlify).

## Selected Topic
Health Care Website

## Technologies Used
- HTML5
- CSS3 (responsive layout with media queries, CSS variables)
- JavaScript (vanilla, no frameworks)
- GitHub (code hosting)
- Netlify (deployment)

## Pages Included
| Page | File | Purpose |
|---|---|---|
| Home | `index.html` | Hero banner, highlights, stats, emergency care, health tips |
| About | `about.html` | Hospital story, mission, why-choose-us, FAQ accordion |
| Departments | `departments.html` | 8 medical departments / services |
| Doctors | `doctors.html` | Doctor profiles + consultation fee estimator |
| Gallery | `gallery.html` | Filterable facility photo gallery with captions |
| Appointment | `appointment.html` | Appointment booking form with validation |
| Contact | `contact.html` | Contact details and emergency information |

## JavaScript Features
1. **Mobile navigation menu** toggle (all pages)
2. **Appointment form validation** — checks required fields, email format, 10-digit phone number, and that the date isn't in the past
3. **Consultation fee estimator** — calculates estimated cost based on doctor and number of family members
4. **Gallery filter** — filters images by category (Facility / Equipment / Emergency)
5. **FAQ accordion toggle** — expand/collapse answers on the About page

## SEO Checklist
- Unique `<title>` tag on every page
- Unique meta description and meta keywords on every page
- One `<h1>` per page, with `<h2>`/`<h3>` for sections
- Descriptive alt text on every image
- Simple, meaningful file names (`about.html`, `departments.html`, `contact.html`, etc.)
- Internal links between related pages (e.g., Home → Appointment, About → Appointment)

## Responsive Design
The layout uses CSS Grid/Flexbox and media queries at 900px and 650px breakpoints, so the site adapts cleanly across mobile, tablet and desktop. The navigation collapses into a toggle menu on small screens.

## How to Run Locally
Open `index.html` in any web browser — no build step or server required.

## How to Deploy (GitHub + Netlify)

### 1. Push the project to GitHub
```bash
cd Venom_Hospital_Website
git init
git add .
git commit -m "Initial commit - Venom Hospital website"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```
Make sure the repository is **public** and includes this `README.md`.

### 2. Deploy on Netlify
1. Go to [https://app.netlify.com](https://app.netlify.com) and log in (you can sign in with GitHub).
2. Click **"Add new site" → "Import an existing project"**.
3. Choose **GitHub** and select this repository.
4. Build settings: leave **Build command** empty and **Publish directory** as the project root (`/`) — this is a static site with no build step.
5. Click **Deploy site**.
6. Once deployed, Netlify gives you a live URL (e.g., `https://your-site-name.netlify.app`). You can rename it under **Site settings → Change site name**.

### 3. Final Submission Checklist
- [ ] GitHub repository link (public, with all files + this README)
- [ ] Netlify live website link (opens correctly)
- [ ] Selected topic noted: **Health Care**

## Customization Notes
- Hospital name, doctor names, fees and contact details in this project are fictional placeholders — replace them with your own content to keep the submission original.
- All images are custom-made SVG graphics (no external/copyrighted images used).
